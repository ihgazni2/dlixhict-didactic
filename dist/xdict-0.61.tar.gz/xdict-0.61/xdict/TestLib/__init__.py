__all__ = ['genrand']
