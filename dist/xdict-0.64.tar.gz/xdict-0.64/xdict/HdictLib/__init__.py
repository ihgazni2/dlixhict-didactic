__all__ = ['hdict']
